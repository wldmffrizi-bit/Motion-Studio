# Motion Studio Android

Original Android video editor foundation.
- Kotlin + Jetpack Compose
- Package: `com.motionstudio`
- Version: `0.2.0`

## Implemented in this iteration
- Import local video/audio through Android Storage Access Framework (`OpenDocument`)
- Persistable URI read permission when supported by the document provider
- Real video/audio playback using AndroidX Media3 ExoPlayer
- Video preview surface using Media3 PlayerView
- Imported clip list, selection, reordering, and removal
- Basic playback time and duration display

## Still not implemented
- Image import and still-image timeline clips
- Frame-accurate timeline scrubbing and trimming
- Multiple simultaneous tracks / compositing
- Project save/load
- Text, keyframes, effects, transitions, and MP4 export

## Build
Open this folder in Android Studio with JDK 17, allow Gradle sync, then run the `app` configuration.

This environment did not include a Gradle executable or Gradle wrapper, so an Android build and device test have not been run here. The Media3 dependency requires Gradle dependency resolution in Android Studio.

## Build APK from an Android phone (cloud build)
1. Create a GitHub repository and upload the contents of this project ZIP.
2. Open the repository's **Actions** tab.
3. Select **Build Motion Studio APK** and tap **Run workflow**.
4. When the run finishes, open it and download the `MotionStudio-debug-apk` artifact.
5. Extract the downloaded artifact ZIP; install `app-debug.apk` on the phone.

The workflow builds a debug APK in GitHub Actions. The APK is not produced until the workflow completes successfully.
