package com.motionstudio

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.UUID

private val Bg = Color(0xFF101116)
private val Panel = Color(0xFF1B1D25)
private val Accent = Color(0xFF8B7CFF)
private val Muted = Color(0xFF9699A8)

private enum class ClipKind { VIDEO, AUDIO }

private data class MediaClip(
    val id: String = UUID.randomUUID().toString(),
    val uri: Uri,
    val name: String,
    val kind: ClipKind
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                MotionStudioApp()
            }
        }
    }
}

@Composable
private fun MotionStudioApp() {
    val context = LocalContext.current
    val clips = remember { mutableStateListOf<MediaClip>() }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Impor video atau audio untuk memulai") }
    var playing by remember { mutableStateOf(false) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var currentMs by remember { mutableLongStateOf(0L) }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = false
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY) {
                    durationMs = player.duration.coerceAtLeast(0L)
                }
                if (playbackState == Player.STATE_ENDED) {
                    currentMs = durationMs
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
                // Some document providers grant a temporary URI permission only.
            }
            val mime = context.contentResolver.getType(uri).orEmpty()
            val kind = if (mime.startsWith("audio/")) ClipKind.AUDIO else ClipKind.VIDEO
            val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
                ?.takeIf { it.isNotBlank() } ?: if (kind == ClipKind.AUDIO) "Audio baru" else "Video baru"
            val clip = MediaClip(uri = uri, name = name, kind = kind)
            clips.add(clip)
            selectedId = clip.id
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = false
            currentMs = 0L
            durationMs = 0L
            status = if (kind == ClipKind.VIDEO) "Video siap diputar" else "Audio siap diputar"
        }
    }

    val selectedIndex = clips.indexOfFirst { it.id == selectedId }
    val selectedClip = clips.getOrNull(selectedIndex)

    LaunchedEffect(player) {
        while (true) {
            currentMs = player.currentPosition.coerceAtLeast(0L)
            if (player.duration > 0L) durationMs = player.duration
            kotlinx.coroutines.delay(200)
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("MOTION STUDIO", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Project baru • 1080 × 1920 • v0.2.0", color = Muted, fontSize = 10.sp)
            }
            TextButton(onClick = { status = "Penyimpanan proyek akan ditambahkan pada tahap berikutnya" }) {
                Text("Simpan", color = Accent)
            }
        }

        Spacer(Modifier.height(10.dp))

        Box(
            Modifier.fillMaxWidth().weight(1f).background(Color(0xFF08090D), RoundedCornerShape(14.dp))
                .border(1.dp, Color(0xFF30323D), RoundedCornerShape(14.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (selectedClip?.kind == ClipKind.VIDEO) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { viewContext ->
                        PlayerView(viewContext).apply {
                            this.player = player
                            useController = false
                            setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                        }
                    },
                    update = { it.player = player }
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (selectedClip?.kind == ClipKind.AUDIO) "♫" else "PREVIEW",
                        color = Accent, fontSize = 36.sp, fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (selectedClip?.kind == ClipKind.AUDIO) "Audio dipilih" else "Belum ada media",
                        color = Color.White, fontSize = 14.sp
                    )
                    Text(status, color = Muted, fontSize = 10.sp)
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Text(formatTime(currentMs), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(" / ${formatTime(durationMs)}", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.weight(1f))
            FilledTonalButton(
                enabled = selectedClip != null,
                onClick = {
                    if (player.isPlaying) player.pause() else player.play()
                }
            ) { Text(if (playing) "Jeda" else "Putar") }
            Spacer(Modifier.width(6.dp))
            Button(onClick = { importLauncher.launch(arrayOf("video/*", "audio/*")) }) {
                Text("＋ Impor")
            }
        }

        Text(status, color = Muted, fontSize = 10.sp, modifier = Modifier.padding(vertical = 4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("TIMELINE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text("${clips.size} klip", color = Muted, fontSize = 10.sp)
        }

        Row(Modifier.fillMaxWidth().height(164.dp)) {
            Column(
                Modifier.width(78.dp).fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                listOf("Video", "Audio").forEach { label ->
                    Box(
                        Modifier.weight(1f).fillMaxWidth().background(Panel, RoundedCornerShape(7.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(label, color = Color.White, fontSize = 11.sp)
                    }
                }
            }
            Spacer(Modifier.width(7.dp))
            if (clips.isEmpty()) {
                Box(
                    Modifier.weight(1f).fillMaxHeight().background(Panel, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Klip yang diimpor akan muncul di sini", color = Muted, fontSize = 10.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxHeight().background(Panel, RoundedCornerShape(8.dp)).padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    itemsIndexed(clips, key = { _, clip -> clip.id }) { index, clip ->
                        val isSelected = clip.id == selectedId
                        Surface(
                            onClick = {
                                selectedId = clip.id
                                player.setMediaItem(MediaItem.fromUri(clip.uri))
                                player.prepare()
                                player.playWhenReady = false
                                currentMs = 0L
                                durationMs = 0L
                                status = "${clip.name} dipilih"
                            },
                            color = if (isSelected) Color(0xFF51458F) else Color(0xFF303340),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (clip.kind == ClipKind.VIDEO) "▣" else "♫",
                                    color = Color.White,
                                    fontSize = 12.sp
                                )
                                Spacer(Modifier.width(7.dp))
                                Text(
                                    clip.name,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                    onClick = {
                                        if (index > 0) {
                                            val item = clips.removeAt(index)
                                            clips.add(index - 1, item)
                                        }
                                    }
                                ) { Text("↑", color = Color.White, fontSize = 11.sp) }
                                TextButton(
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp),
                                    onClick = {
                                        clips.remove(clip)
                                        if (selectedId == clip.id) {
                                            player.stop()
                                            selectedId = clips.firstOrNull()?.id
                                            val next = clips.firstOrNull()
                                            if (next != null) {
                                                player.setMediaItem(MediaItem.fromUri(next.uri))
                                                player.prepare()
                                                status = "${next.name} dipilih"
                                            } else {
                                                status = "Timeline kosong"
                                                durationMs = 0L
                                                currentMs = 0L
                                            }
                                        }
                                    }
                                ) { Text("×", color = Color.White, fontSize = 14.sp) }
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = { status = "Pilih klip di timeline untuk mengelolanya" }) {
                Text("Klip", color = Color.White, fontSize = 10.sp)
            }
            TextButton(onClick = { status = "Pemotongan klip akan menjadi fitur tahap berikutnya" }) {
                Text("Potong", color = Color.White, fontSize = 10.sp)
            }
            TextButton(onClick = { status = "Layer teks akan ditambahkan pada Tahap 2" }) {
                Text("Teks", color = Color.White, fontSize = 10.sp)
            }
            TextButton(onClick = { status = "Panel efek akan ditambahkan pada Tahap 4" }) {
                Text("Efek", color = Color.White, fontSize = 10.sp)
            }
        }
    }
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val millis = (milliseconds.coerceAtLeast(0L) % 1000L) / 10
    return "%02d:%02d:%02d".format(minutes, seconds, millis)
}
